﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 预定义
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
           
        }
    }
}
