﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 从类的外部访问静态成员
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
