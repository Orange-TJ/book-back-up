﻿namespace 分布方法
{
    internal class partial
    {
    }
}